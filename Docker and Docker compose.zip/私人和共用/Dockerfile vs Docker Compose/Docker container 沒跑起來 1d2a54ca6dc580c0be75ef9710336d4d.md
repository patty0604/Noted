# Docker container 沒跑起來?

## 情境：Docker container 沒跑起來

執行了以下指令啟動一個 Flask 專案：

```bash

docker run -d -p 5000:5000 my-flask-app

```

結果發現：

- `docker ps` 看不到 container
- 用 `curl http://localhost:5000` 也連不到

---

## 🔍 排查步驟與解法：

### 1. 查看 container 有沒有其實「起來又馬上掛掉」

```bash

docker ps -a

```

如果看到像這樣的輸出：

```bash

CONTAINER ID   IMAGE           COMMAND             STATUS                      PORTS     NAMES
abc123         my-flask-app    "python app.py"     Exited (1) 5 seconds ago              funny_panda

```

→ `Exited (1)` 表示有錯，程式跑了但當掉了。

---

### 2. 查看當掉的原因（log）

```bash

docker logs abc123

```

假設你看到錯誤：

```

ModuleNotFoundError: No module named 'flask'

```

### ✅ 解法：

這表示你的 Dockerfile 裡沒有安裝 Flask，你需要加上：

```

RUN pip install flask

```

然後重新 build image：

```bash
docker build -t my-flask-app .

```

再重新 run：

```bash

docker run -d -p 5000:5000 my-flask-app

```