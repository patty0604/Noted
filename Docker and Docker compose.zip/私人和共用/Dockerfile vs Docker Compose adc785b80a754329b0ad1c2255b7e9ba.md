# Dockerfile vs. Docker Compose

<u>**電子書資源:**</u>

[Docker-從入門到實踐.pdf](Dockerfile%20vs%20Docker%20Compose/Docker-%25E5%25BE%259E%25E5%2585%25A5%25E9%2596%2580%25E5%2588%25B0%25E5%25AF%25A6%25E8%25B8%2590.pdf)

<u>**網站內容教學:**</u>

https://cutejaneii.gitbook.io/docker/docker/untitled

<u>**疑難雜症額外內容:**</u>

[Docker container 沒跑起來?](Dockerfile%20vs%20Docker%20Compose/Docker%20container%20%E6%B2%92%E8%B7%91%E8%B5%B7%E4%BE%86%201d2a54ca6dc580c0be75ef9710336d4d.md)

# 概述

Dockerfile 和 Docker Compose 是用來定義和管理 Docker 容器的兩個不同工具。它們各自有不同的作用，但通常一起使用來構建和運行容器化的應用程序。

# Docker

![Untitled](Dockerfile%20vs%20Docker%20Compose/Untitled.png)

Docker利用 Dockerfile預先建置好一個 Docker Image(映像檔)。在使用者想要使用容器的時候，以該映像檔為基礎，運行一個對應的Docker容器。

## Docker vs. 傳統虛擬化方式

![Untitled](Dockerfile%20vs%20Docker%20Compose/Untitled%201.png)

### 傳統虛擬化

傳統虛擬化技術主要是通過虛擬機（Virtual Machine，VM）來實現。虛擬機器管理程式（Hypervisor）在硬體層之上運行，並在每個虛擬機中模擬完整的硬體環境，允許多個操作系統同時運行在同一物理機器上。

**特點**：

1. <u>**完整的操作系統**</u>：每個虛擬機都包含一個完整的操作系統（Guest OS），這意味著每個虛擬機都有自己的內核、文件系統和應用程式。
2. <u>**資源佔用**</u>：由於每個虛擬機都有自己的操作系統，資源（CPU、內存、硬碟等）佔用較多。
3. <u>**啟動時間**</u>：啟動虛擬機需要時間，因為需要加載完整的操作系統。
4. <u>**隔離性**</u>：虛擬機之間完全隔離，這意味著一個虛擬機的問題不會影響到其他虛擬機。
5. <u>**管理和維護**</u>：管理和維護虛擬機較為複雜，因為每個虛擬機都像是一個完整的物理機，需要個別配置和管理。

### Docker 容器

Docker 使用容器技術來實現虛擬化。容器共享宿主操作系統的內核，但運行在獨立的用戶空間中，這使得容器更加輕量級且高效。

**特點**：

1. <u>**共享操作系統**</u>：容器共享宿主操作系統的Kernal，避免了每個容器運行一個完整的操作系統的開銷。
2. <u>**輕量級**</u>：由於沒有完整的操作系統，容器佔用的資源較少。可以在一台物理機上運行更多的容器。
3. <u>**快速啟動**</u>：容器的啟動幾乎是瞬間完成的，因為不需要加載完整的操作系統。
4. <u>**高效的資源利用**</u>：容器使用宿主操作系統的內核，因此資源利用率更高。
5. <u>**隔離性**</u>：儘管容器共享宿主操作系統的內核，但它們的文件系統、進程空間和網絡是隔離的，這保證了安全性和穩定性。
6. <u>**可移植性**</u>：容器化的應用程式可以在任何支持 Docker 的環境中運行，無需修改。

傳統的vm需要先決定應用程式要在幾核的CPU下、多少RAM、多少硬碟空間、使用何種OS。因此，就算實際運行過後發現有剩餘資源沒有用上，也不能給其他應用程式使用。

→ Docker解決了此困境。

| 特點 | 傳統虛擬化 | Docker 容器 |
| --- | --- | --- |
| 操作系統 | 每個虛擬機有自己的操作系統 | 共享主機的操作系統 |
| 啟動時間 | 幾分鐘 | 幾秒鐘 |
| 資源佔用 | 高（每個虛擬機有完整的 OS） | 低（共享主機 OS 的kernal） |
| 隔離性 | 完全隔離 | 文件系統和進程空間隔離 |
| 性能開銷 | 相對較高 | 較低 |
| 可移植性 | 受限於虛擬機環境 | 高（可以在任何 Docker 環境運行） |
| 運行環境 | 重型應用程式和長期運行的服務 | 微服務、輕量級和短期任務 |
| 管理和維護 | 較為複雜（需要管理多個操作系統） | 簡單（管理容器和映像檔） |

# Docker 與 Podman 比較

![image.png](Dockerfile%20vs%20Docker%20Compose/image.png)

![image.png](Dockerfile%20vs%20Docker%20Compose/image%201.png)

# Dockerfile

## Dockerfile 是什麼？

Dockerfile 是一個包含一組指令的文本文件，用於自動化地構建 Docker image。每個指令對應於一個步驟，這些步驟會依序執行以創建最終的image。

## Dockerfile 基本參數

### 1. `FROM`

指定基礎映像，所有的 Dockerfile 都從這個指令開始。例如：

```
FROM python:3.8-slim

```

### 2. `WORKDIR`

設置工作目錄。所有後續的指令將在這個目錄下執行。例如：

```
WORKDIR /app

```

### 3. `COPY`

將文件或目錄從主機系統複製到映像中。例如：

```
COPY . /app

```

### 4. `RUN`

執行命令來安裝應用程序所需的軟件包。例如：

```
RUN pip install --no-cache-dir -r requirements.txt

```

### 5. `CMD`

設置容器啟動時執行的命令。每個 Dockerfile 只能有一個 CMD 命令。例如：

```
CMD ["python", "app.py"]

```

### 6. `EXPOSE`

聲明容器將會使用的端口。例如：

```
EXPOSE 4008
```

<aside>
✨ 注意:
如果port想要設定為5000以外的數字，不僅需要在Dockerfile 中的EXPOSE設定，在app.py也要寫參數port=???

如以下程式碼:

```bash

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=4008)
```

- `host='0.0.0.0'`：這樣設定可以讓你的應用在所有可用的網絡接口上運行，這在 Docker 容器中非常重要，因為容器內部的應用需要被外部訪問。
- `port=4008`：這樣明確指定了應用運行的端口，使其與 Docker 映像的暴露端口一致。
</aside>

## 範例 Dockerfile1

假設我們有一個 Python Web 應用程序，我們想要把它打包成 Docker 映像。應用的文件結構如下：

```
myapp/
│
├── app.py
├── requirements.txt
└── Dockerfile

```

`app.py` 是你的主程序，`requirements.txt` 列出了你的 Python 依賴包。這是你的 Dockerfile：

```
# 使用基礎 Python 映像
FROM python:3.9-slim

# 設置工作目錄
WORKDIR /app

# 複製當前目錄下的所有文件到工作目錄
COPY . /app

# 安裝依賴
RUN pip install --no-cache-dir -r requirements.txt

# 暴露端口
EXPOSE 5000

# 設置容器啟動時運行的命令
CMD ["python", "app.py"]
```

### 參數詳細解釋

1. **FROM**: 使用官方的 Python 3.9-slim 基礎映像。 決定使用者的容器的操作系統環境、預裝的軟件以及其他設置。不同的標籤（tags）對應於基礎映像的不同版本和配置。
2. **WORKDIR**: 將工作目錄設置為 `/app`。
3. **COPY**: 將主機系統中當前目錄的所有文件複製到容器的 `/app` 目錄。
4. **RUN**: 執行命令來安裝 Python 依賴。
5. **EXPOSE**: 暴露應用程序運行的端口 5000。
6. **CMD**: 設置容器啟動時運行的命令 `python app.py`。

### 構建和運行容器

1. 在你的應用目錄下打開終端。
2. 執行以下命令來構建 Docker 映像：

```bash
docker build -t myapp:latest .

```

1. 使用以下命令運行容器：

```bash
docker run -p 5000:5000 myapp:latest
docker run -d --name myapp -p 4012:4012 myapp:latest

```

## 範例 Dockerfile2

我寫的ConvertRolloutPlan專案中的dockerfile:

```bash
FROM python:3.8-slim-buster

# 設置工作目錄
WORKDIR /app

# 複製 requirement.txt 文件並安裝
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 複製全部
COPY . .

# port設置
EXPOSE 4008

# 啟動Flask應用
CMD ["python", "app.py"]
```

app.py:

```bash
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=4008)
```

## Docker 指令大全

放在子頁面:  

[Docker 指令大全](Dockerfile%20vs%20Docker%20Compose/Docker%20%E6%8C%87%E4%BB%A4%E5%A4%A7%E5%85%A8%20891d72b24f874f69a5a852c228dc397f.md)

# Docker Compose範例

**Docker Compose** 是一個用來定義和運行多容器 Docker 應用的工具。你可以使用 Docker Compose 定義一個包括多個服務（每個服務運行一個容器）的應用。

Docker Compose 使用 YAML 文件來配置應用的服務。你可以在一個文件中定義所有需要的服務，以及它們之間的網絡配置。

```yaml
# 文件名稱 : docker-compose.yml
version: '3.9'

services:
    host-db-service:
        restart: always
        image: 10.1.1.11:5500/mongo:4.4.5
        volumes:
            - /app/volumes/host-db-service/data/db:/data/db
        container_name: services_host-db-service
        ports: 
            - 27017:27017
        networks:
            mongodb:
                aliases:
                    - db-service
    host-db-api:
        restart: always
        image: 10.1.1.11:5500/host-db-api
        volumes:
            - /app/services/host-db-service/host-db-api:/app
        container_name: services_host-db-api
        ports: 
            - 5000:5000
        networks:
            mongodb:
                aliases:
                    - db-api
            automation:
                aliases:
                    - db-api
networks:
    mongodb:
    automation:
        external: 
            name: automation
```

# Dockerfile 和 Docker Compose 的關係

1. **Dockerfile** 用來構建一個單獨的應用程式的Docker鏡像。它被用來構建 專案(`host-db-api`) 的鏡像。
2. **Docker Compose** 用來定義和管理一組相關的服務。它使用Dockerfile構建的鏡像以及其他已存在的鏡像來運行這些服務。
在範例中，它定義了 `host-db-service` 和 `host-db-api` 兩個服務，並配置它們的網絡、端口和數據卷。

Dockerfile可用來建立Docker image，Docker Compose 負責管理這些由不同Dockerfile所建立的Docker image。

# Docker image上傳到私人的倉庫

## (可選) 撰寫.dockerignore

把不想包在docker裡的檔案都寫在這裡，與.gitignore功能相同

![Untitled](Dockerfile%20vs%20Docker%20Compose/Untitled%202.png)

## 構建Docker image

請先cd到 Dockerfile同目錄:

```bash
docker build -t <api_name> .
-> docker build -t reportfusion_api .
```

## push

```bash
docker tag convertrolloutplan_api:latest 10.1.1.11:5500/convertrolloutplan_api:latest
# 推送
docker push 10.1.1.11:5500/convertrolloutplan_api
```

## 查看是否有推送成功

```bash
curl -sS 10.1.1.11:5500/v2/_catalog  --> 看registry有的image
curl -sS 10.1.1.11:5500/v2/pdconverter_api/tags/list --> 看registry上這個image有的版本
```

## 登入vm

```bash
ssh automan@10.1.1.11
auto123
```

## 在vm上操作

```bash
docker pull 10.1.1.11:5500/convertrolloutplan_api # 將倉庫的image拉下來
docker run -d -p 4008:4008 --name convertrolloutplan_api 10.1.1.11:5500/convertrolloutplan_api # 將image啟動成container
```

## * Bind vm 目錄

```bash
docker run -d -p 4002:4002 -v /app/volumes/pinlog:/mnt/PINTestLog --name reportfusion_api 10.1.1.11:5500/reportfusion_api
```

## 測試api

1. 先去看是否有在運作:

```bash
docker ps

```

![Untitled](Dockerfile%20vs%20Docker%20Compose/Untitled%203.png)

1. 在POSTMAN中設定Header 

![Untitled](Dockerfile%20vs%20Docker%20Compose/Untitled%204.png)

1. 在POSTMAN中設定body

![Untitled](Dockerfile%20vs%20Docker%20Compose/Untitled%205.png)

1. 輸入request方法(GET、POST、DELETE…..)，按下Send

1. 進入 Docker 容器

使用 `docker exec` 命令進入正在運行的容器，然後在容器內檢查文件。

```bash
docker exec -it 6bdb7ca22c72 /bin/bash
# 可以先用ls看有什麼檔案
cat /app/CRP.log
```

1. 退出Docker容器

```bash
exit
```

![Untitled](Dockerfile%20vs%20Docker%20Compose/Untitled%206.png)

# (工作筆記)API更新後重啟docker-compose

因為目前Pinweb的container都是用docker-compose建起來的
如果你要更新單隻的image，請先docker pull更新image之後
用這幾個指令把PINWEB相關的container 一口氣重啟

```bash

cd /app
sudo DB_REGISTRY_GITLAB_URL="10.1.1.11" docker-compose -p PinWeb -f "docker-compose_pinweb.yml" down
sudo DB_REGISTRY_GITLAB_URL="10.1.1.11" docker-compose -p PinWeb -f "docker-compose_pinweb.yml" up -d
```

否則VM在跑自動化的環境建置時會遇到error

# (工作筆記)

1. 先build好docker image並上傳到10.1.1.11的regitry
2. 將registry上新版image拉到local
    
    "docker image pull <image_name>" (e.g. docker image pull 10.1.1.11:5500/pinweb)
    
    ```jsx
    docker pull 10.1.1.11:5500/pdconverter_api
    ```
    
3. 先手動關閉該隻container
    
    ```jsx
    docker rm -f convertrolloutplan_api
    ```
    
4. cd 到app資料夾 

```jsx
cd /app  
```

1. 利用docker-compose重建砍掉的container

```jsx
sudo DB_REGISTRY_GITLAB_URL="10.1.1.11" docker-compose -p PinWeb -f "docker-compose_pinweb.yml" up --no-recreate -d
```

![image.png](Dockerfile%20vs%20Docker%20Compose/image%202.png)

掛載教學:

[https://blog.myctw.cc/post/b3ea.html](https://blog.myctw.cc/post/b3ea.html)

# 大溪

大家午安~~
如果有docker image 需要更新到大溪，請在你的"開發機"上使用
docker save -o filename.tar <repo>:<tag>

例如: docker save -o pinweb-20241021.tar 10.1.1.11:5500/pinweb:latest
docker image會被轉存為tar檔案，接著上傳到我的onedrive : Docker Image
**或者，你可以用任何你方便的方法，把這個tar放到"大溪的NAS"  的 "KeyImg" 資料夾裡面

完成上面的動作之後請再通知我遠端過去更新，感謝大家